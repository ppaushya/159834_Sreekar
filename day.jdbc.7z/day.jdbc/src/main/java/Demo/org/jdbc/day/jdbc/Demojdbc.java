package Demo.org.jdbc.day.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demojdbc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
			String sql=" create table employee(empId int primary key , firstName varchar(25) , lastName varchar(25),salary numeric(8,2) , empdoj date)";
					
			
			Statement statement = connection.createStatement();
			
			boolean flag =statement.execute(sql);
  if(!flag) {
	  System.out.println("Table created");
					
  }
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	}


