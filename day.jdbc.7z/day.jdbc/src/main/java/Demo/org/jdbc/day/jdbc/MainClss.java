package Demo.org.jdbc.day.jdbc;

import java.util.List;
import java.time.LocalDate;
import java.util.Scanner;

import org.apache.log4j.Logger;




public class MainClss {
	final static Logger logger= Logger.getLogger(MainClss.class);
	public static void main(String[] args) {
		
			
		
		// TODO Auto-generated method stub;
		Scanner scanner = new Scanner(System.in);
		UserInteraction userInteraction=new UserInteraction();
		EmployeeDao employeeDao=new EmployeeDaoImp();
		int option;
		String choice;
		do {
		System.out.println("1.Create Employee");
		System.out.println("2.Update Employee");
		System.out.println("3.Delete Employee");
		System.out.println("4.List All Employee");
		System.out.println("5.Find Employee");
		System.out.println("6.call the procedure");
		System.out.println("7.Bulk operation");
		System.out.println("8.Exit");
		System.out.println("Enter your option:");
		option=scanner.nextInt();
			switch(option) {
			case 1:
			//	Employee employee=new Employee(789, "Kamal", "jERRY", 23000, LocalDate.of(2010,3,12));
				Employee employee=userInteraction.createEmployee();
				employeeDao.createEmp(employee);
				break;
			case 2:
				
				break;
			case 3:
				int empId=userInteraction.promptEmployeeID();
				employeeDao.deleteEmp(empId);
				break;
			case 4:
				List <Employee> employees= employeeDao.getAllEmployees();
				userInteraction.printAllEmployees(employees);
				break;
			case 5:
				int empId1=userInteraction.promptEmployeeID();
				List<Employee> employees2=employeeDao.findEmp(empId1);
				userInteraction.printAllEmployees(employees2);
				
				break;
			case 6:
				   int empid2 = userInteraction.promptEmployeeID();
				   Employee employee1=employeeDao.callProcedure(empid2);
				   System.out.println(employee1);
				break;
			case 7:
				    employeeDao.bulkOperation();
				break;
			case 8:
				
				System.exit(0);
			default:
				System.out.println("Sorry! Invalid Option!");
			}
			System.out.println("You wish to continue[y|n]:");
			choice=scanner.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		}

	MainClss obj= new MainClss();
	
	private void runMe(String parameter ) {
		
		if(logger.isDebugEnabled()) {
			logger.debug("This is debug:" + parameter);
		}
		if(logger.isInfoEnabled()) {
			logger.info("This is info:" + parameter);
		}
		logger.warn("This is warn:" + parameter);
		logger.error("This is error :" + parameter);
		logger.fatal("This is fatal:" + parameter);
	}

}
	
