package Demo.org.jdbc.day.jdbc;

import java.sql.SQLException;
import java.util.List;

public interface EmployeeDao {
	
	public void createEmp(Employee employee);
	public void deleteEmp(int empId);
	
	public List<Employee>  getAllEmployees();
	public List<Employee>  findEmp(int empID);
	public void bulkOperation();
	public Employee callProcedure(int employeeId);
	public void uptadeEmp(int employeeId , Employee employee) throws SQLException;
	

}
