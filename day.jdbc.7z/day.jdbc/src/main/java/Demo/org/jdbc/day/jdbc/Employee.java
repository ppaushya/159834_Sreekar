package Demo.org.jdbc.day.jdbc;

import java.time.LocalDate;

public class Employee {

	private int EmpId;
	private String firstName;
	private String lastName;
	private double salary;
	private LocalDate date;
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Employee [EmpId=" + EmpId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", date=" + date + "]";
	}
	public Employee(int empId, String firstName, String lastName, double salary, LocalDate date) {
		super();
		EmpId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.date = date;
	}
	
	public Employee() {
		
	}
	
}
