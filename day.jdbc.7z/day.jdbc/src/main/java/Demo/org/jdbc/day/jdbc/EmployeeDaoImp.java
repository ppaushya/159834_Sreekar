package Demo.org.jdbc.day.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImp implements EmployeeDao {

	@Override
	public void createEmp(Employee employee) {
		// TODO Auto-generated method stub
		Connection connection=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			String sql= "insert into employee values(?,?,?,?,?)";
		 connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
			PreparedStatement statement =connection.prepareStatement(sql);
			statement.setInt(1, employee.getEmpId());
			statement.setString(2, employee.getFirstName());
			statement.setString(3, employee.getLastName());
			statement.setDouble(4,employee.getSalary());
			statement.setDate(5, java.sql.Date.valueOf(employee.getDate()));
			 int count=statement.executeUpdate();
			 
			if(count>0) {
				System.out.println("insertion done");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}

	@Override
	public void deleteEmp(int empId) {
		Connection connection=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			String sql= "delete into employee where empId=?";
		 connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
			PreparedStatement statement1 =connection.prepareStatement(sql);
			statement1.setInt(1, empId);
			
			int count =statement1.executeUpdate();
			if(count>0) {
				System.out.println("Deletion done");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//			statement.setInt(1, employee.getEmpId());
//			statement.setString(2, employee.getFirstName());
//			statement.setString(3, employee.getLastName());
//			statement.setDouble(4,employee.getSalary());
//			statement.setDate(5, java.sql.Date.valueOf(employee.getDate()));
//		}	 int count=statement.executeUpdate();
		}
	}
		public List<Employee> getAllEmployees() {
			List<Employee> employees=new ArrayList<>();
			Connection connection=null;
			try {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String sql= "select * from employee ";
			 connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
			String sql1="select * from employee";
			
				PreparedStatement pst=connection.prepareStatement(sql);
				ResultSet resultSet= pst.executeQuery();
				while(resultSet.next()) {
					Employee employee=new Employee();
					employee.setEmpId(resultSet.getInt(1));
					employee.setFirstName(resultSet.getString("firstName"));
					employee.setLastName(resultSet.getString("lastName"));
					employee.setSalary(resultSet.getDouble("salary"));
					employee.setDate(resultSet.getDate(5).toLocalDate());
					employees.add(employee);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return employees;
			}finally {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();		
	
		}
			}
			return employees;
		}


		@Override
		public List<Employee> findEmp(int empID) {
			List<Employee> employees=new ArrayList<>();
		
			Connection connection=null;
		
			try {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String sql= "select * from employee where EmpId=?";
			 connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
			
			 PreparedStatement pst1=connection.prepareStatement(sql);
				pst1.setInt(1, empID);
			 ResultSet resultset =pst1.executeQuery();
			 while(resultset.next()) {
					Employee employee=new Employee();
					employee.setEmpId(resultset.getInt(1));
					employee.setFirstName(resultset.getString("firstName"));
					employee.setLastName(resultset.getString("lastName"));
					employee.setSalary(resultset.getDouble("salary"));
					employee.setDate(resultset.getDate(5).toLocalDate());
					employees.add(employee);
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 
			return employees;
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			return employees;
		}

		@Override
		public void bulkOperation() {
		 Connection connection = null;
		 try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
			String str1= "insert into employee values(100,'Prakash','Mohan',89555,'2001-08-06')";
			String str2= "insert into employee values(101,'Shubam','Kumar',89555,'2001-08-06')";
			String str3= "insert into employee values(102,'Vinod','kaul',89555,'2001-08-06')";
			String str4= "insert into employee values(103,'Kishore','Sai',89555,'2001-08-06')";
			String str5= "insert into employee values(104,'Tom','Jerry',89555,'2001-08-06')";
			
			 Statement statement=connection.createStatement();
			 statement.addBatch(str1);
			 statement.addBatch(str2);
			 statement.addBatch(str3);
			 statement.addBatch(str4);
			 statement.addBatch(str5);
			 
			  int[] result=statement.executeBatch();
			  
			  for(int out: result) {
				  System.out.println(out);
			  }
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
			
		}
	
		

		}

		@Override
		public Employee callProcedure(int employeeId) {
			try {
			Connection connection = null;
				
				CallableStatement callableStatement=connection.prepareCall("{ call  findEmployee(?,?,?,?)}");
				callableStatement.setInt(1, employeeId);
				callableStatement.registerOutParameter(2,Types.VARCHAR);
				callableStatement.registerOutParameter(3, Types.VARCHAR);
				callableStatement.registerOutParameter(4, Types.DOUBLE);
				
				callableStatement.execute();
				
				String fname=callableStatement.getString(2);
				String lname=callableStatement.getString(3);
				double salary=callableStatement.getDouble(4);
				
				Employee employee=new Employee();
				employee.setFirstName(fname);
				employee.setLastName(lname);
				employee.setSalary(salary);
				employee.setEmpId(employeeId);
				
				
				return employee;
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			return null;
		}

		@Override
		public void uptadeEmp(int employeeId , Employee employee) throws SQLException {
			boolean flag=true;
			Connection connection = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
				String sql = "uptade employee set firstName=? where empId=?";
				PreparedStatement statement =connection.prepareStatement(sql);
				statement.setString(1, employee);
				statement.setInt(2, employeeId);
				if(!flag)
				{
					System.out.println("Updated successfully!");
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}
			
		
			public void uptadeEmp(int employeeId , double salary) throws SQLException {
				boolean flag=true;
				Connection connection = null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
					String sql = "uptade employee set salary=? where empId=?";
					PreparedStatement statement =connection.prepareStatement(sql);
					statement.setDouble(1, salary);
					statement.setInt(2, employeeId);
					if(!flag)
					{
						System.out.println("Updated successfully!");
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

					
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			
		}
		}
			
		
