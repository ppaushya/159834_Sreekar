package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDBDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("ServiceDbImp")
public class IPilotDBServiceImpl implements IPilotService {

	@Autowired
	private IPilotDBDao pilotDBdao;
	
	@Override
	public List<Pilot> getAllPilots() {
		// TODO Auto-generated method stub
		return pilotDBdao.findAll();
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
	   Pilot pilot =pilotDBdao.findById(pilotId).get();
	         return pilot;
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		// TODO Auto-generated method stub
		pilotDBdao.save(pilot);
		return  getAllPilots();
	}

	@Override
	public List<Pilot> deletepilot(Integer pilotId) {
		// TODO Auto-generated method stub
		
				pilotDBdao.deleteById(pilotId);
				return getAllPilots();
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		// TODO Auto-generated method stub
		pilotDBdao.save(pilot);
		return  getAllPilots();
	}
	

}
