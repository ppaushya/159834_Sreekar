package org.gaming.model;

public class Registration {

	
	private int registrationId;
	
	private String customerName;
	
	private String mobileNumber;
	
	private double registrationFee;
	
	private int age;
	
	private double actualRegFeePaid;

	public int getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public double getRegistrationFee() {
		return registrationFee;
	}

	public void setRegistrationFee(double registrationFee) {
		this.registrationFee = registrationFee;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getActualRegFeePaid() {
		return actualRegFeePaid;
	}

	public void setActualRegFeePaid(double actualRegFeePaid) {
		this.actualRegFeePaid = actualRegFeePaid;
	}

	@Override
	public String toString() {
		return "Registration [registrationId=" + registrationId + ", customerName=" + customerName + ", mobileNumber="
				+ mobileNumber + ", registrationFee=" + registrationFee + ", age=" + age + ", actualRegFeePaid="
				+ actualRegFeePaid + "]";
	}

	public Registration(int registrationId, String customerName, String mobileNumber, double registrationFee, int age,
			double actualRegFeePaid) {
		super();
		this.registrationId = registrationId;
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.registrationFee = registrationFee;
		this.age = age;
		this.actualRegFeePaid = actualRegFeePaid;
	}

	public Registration() {
		super();
	}

	public Registration(String customerName, String mobileNumber, double registrationFee, int age) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.registrationFee = registrationFee;
		this.age = age;
	}

	public Registration(String customerName, String mobileNumber, double registrationFee, int age,
			double actualRegFeePaid) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.registrationFee = registrationFee;
		this.age = age;
		this.actualRegFeePaid = actualRegFeePaid;
	}
	
	
	
	
}
