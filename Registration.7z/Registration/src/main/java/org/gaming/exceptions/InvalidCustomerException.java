package org.gaming.exceptions;

public class InvalidCustomerException extends Exception {
        
	public InvalidCustomerException(String string)
	{
		super(string);
	}
}
