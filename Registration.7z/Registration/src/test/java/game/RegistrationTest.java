package org.cap.game.reg.game;

import junit.framework.TestCase;
import org.game.dao.IRegistrationDao;

import org.game.dao.RegistrationDaoImpl;

import org.game.exception.InvalidAgeException;

import org.game.model.Registration;

import org.game.service.IRegistrationService;

import org.game.service.RegistrationServiceImpl;

import org.junit.Before;

import org.junit.Test;

import org.mockito.Mock;

import org.mockito.Mockito;

import org.mockito.MockitoAnnotations;

public class RegistrationTest extends TestCase {
	
	
	
	 @Mock

     CustomerDaoImpl customerDao;

    

     ICustomerService customerService;

    

     @Before

     public void setUpBeforeClass(){

            MockitoAnnotations.initMocks(this);

            registrationService = new CustomerServiceImpl(registrationDao);

     }



     @Test(expected=IllegalArgumentException.class)

     public void test_createRegistration_method_with_null() throws InvalidAgeException {

            Registration registration = null;

           

            customerService.createRegistration(registration);

     }

    

     @Test(expected=InvalidAgeException.class)

     public void test_createRegistration_method_with_invalid_age() throws InvalidAgeException {

            Registration registration = new Registration(1001, "shilu", "9848452", 1000.0,3, 1000.0);

           

            customerService.createRegistration(registration);

     }



     @Test

     public void test_createRegistration_method_with_success() throws InvalidAgeException {

            Registration registration = new Registration(1002, "Kittu", "9544589", 1000.0, 25, 1000.0);

           

            Mockito.when(customerDao.createRegistration(registration)).thenReturn(registration);

            customerService.createRegistration(registration);

           

            Mockito.verify(customerDao).createRegistration(registration);

     }

    

     @Test

     public void test_getActualFees_method(){

            CustomerServiceImpl serviceImpl = new CustomerServiceImpl();

            assertEquals(11000, serviceImpl.calculateRegFee(10000.0, 20),0.0);

}
