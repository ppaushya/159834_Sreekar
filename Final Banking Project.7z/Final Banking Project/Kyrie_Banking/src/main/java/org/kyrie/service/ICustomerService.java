package org.kyrie.service;

import java.util.List;
import java.util.Set;

import org.kyrie.model.Account;
import org.kyrie.model.Customer;

public interface ICustomerService {
	
public boolean createCustomer(Customer customer) ;
	
	public List<Customer> getAllCustomers();
	
	public Customer getCustomerFromCustomerId(long customerId);
}