package org.kyrie.view;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.kyrie.dao.CustomerDaoImp;
import org.kyrie.model.Account;
import org.kyrie.model.AccountType;
import org.kyrie.model.Address;
import org.kyrie.model.Customer;
import org.kyrie.service.CustomerServiceImp;
import org.kyrie.util.Utilty;
import org.kyrie.util.Validator;

public class UserInteraction {
static Scanner scanner = new Scanner(System.in);
	
	public static int getTaskChoiceFromUser() {
		int choice=0;
		while(choice<1 || choice>4) {
			System.out.println();
			System.out.println("----------------------------------");
			System.out.println("1. Create a  Customer");
			System.out.println("2. List of Customers");
			System.out.println("3. Select aCustomer");
			System.out.println("4. Exit");
			System.out.println("Enter your choice[1 or 2 or3 or 4]: ");
			choice = scanner.nextInt();
			if(choice<1 || choice>4) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getCustomerTaskChoiceFromUser() {
		int choice=0;
		while(choice<1 || choice>5) {
			System.out.println();
			System.out.println();
			System.out.println("1. Create a  Account");
			System.out.println("2. Perform a Transaction");
			System.out.println("3. Transaction  summary :");
			System.out.println("4. Current Balance is ");
			System.out.println("5. Cancel");
			System.out.println("Enter your choice[1 or 2 or 3 or 4 or 5]: ");
			choice = scanner.nextInt();
			if(choice<1 || choice>5) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	public static int getTransactionTypeChoiceFromUser() {
		int choice=0;
		while(choice<1 || choice>3) {
			System.out.println();
			System.out.println();
			System.out.println("1. Debit");
			System.out.println("2. Credit");
			System.out.println("3. Fund Transfer");
			System.out.println("4. Cancel");
			System.out.println("Enter your choice[1 or 2 or 3 or 4]: ");
			choice = scanner.nextInt();
			if(choice<1 || choice>3) {
				System.out.println("Sorry! Invalid choice. Please try again!");
			}
		}
		return choice;
	}
	
	private static LocalDate getDateFromUser(String message) {
		String date="";
		while(!Validator.validateDate(date)) {
			System.out.println(message);
			date = scanner.next();
		}
		String dateParts[] = date.split("-");
		return LocalDate.of(Integer.parseInt(dateParts[2]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[0]));
	}
	
	public static boolean getRepeatConfirmation() {
		boolean shouldRepeat = false;
		System.out.println("Do you wish to continue? [y/n]:");
		String choice = scanner.next();
		shouldRepeat = choice.charAt(0)=='y' || choice.charAt(0)=='Y';
		return shouldRepeat;
	}

}
