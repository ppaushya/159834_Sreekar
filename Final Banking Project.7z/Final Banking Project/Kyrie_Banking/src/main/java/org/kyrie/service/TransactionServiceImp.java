package org.kyrie.service;

import java.util.Set;

import org.kyrie.dao.ITransactionDao;
import org.kyrie.dao.TransactionDaoImp;
import org.kyrie.dao.TransactionDbImp;
import org.kyrie.model.Account;
import org.kyrie.model.Customer;
import org.kyrie.model.Transaction;



public class TransactionServiceImp implements ITransactionService{
	ITransactionDao transactionDao = new TransactionDaoImp();
	ITransactionDao transactionb = new TransactionDbImp();
	
	public Set<Transaction> getAllTransactions() {
		return transactionDao.getAllTransactions();
	}
	
	public Set<Transaction> getAllTransactionsOfCustomer(Customer customer) {
		return transactionDao.getAllTransactionsOfCustomer(customer);
	}
	
	public Set<Transaction> getAllTransactionsOfAccount(Account Account) {
		return transactionDao.getAllTransactionsOfAccount(Account);
	}
	
	public void createTransaction(Transaction transaction) {
		transactionDao.createTransaction(transaction);		
	}


}
