package org.kyrie.dao;

import java.util.List;

import org.kyrie.model.Account;
import org.kyrie.model.Customer;

public interface ICustomerDao {
public List<Customer> getAllCustomers();
	
	public void create_Customer(Customer customer);
	
	public Customer get_Customer_From_CustomerId(long customerId);
}


