package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/performTrans")
public class performTrans extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		ILoginService loginservice = new LoginServiceImpl();
		List<Account> acc=loginservice.maketransaction((session.getAttribute("custId").toString()));		
	//	Account acc=loginservice.getAccount(Long.parseLong(session.getAttribute("custId").toString());
		PrintWriter out =response.getWriter();

		  for(Account ac:acc) {
			  System.out.println(ac);
		  }

                out.println("<html>\r\n" +

                            "<head>\r\n" +

                            "<meta charset=\"ISO-8859-1\">\r\n" +

                            "<title>Deposit/Withdrawal</title>\r\n" +

                            "</head>\r\n" +

                            "<body>\r\n" +

                            "<form method=\"get\" action=\"./performTransPost\">\r\n" +

                            "      <div>\r\n" +

                            "             <table>\r\n" +

                            "                    <tr>\r\n" +

                            "                          <h4><th colspan=\"3\">Transactions</th>\r\n</h4>" +

                            "                    </tr>\r\n" +

                            "                    <tr>\r\n" +

                            "                          <td>Select Account:</td>\r\n" +

                            "                          <td>\r\n" +

                            "                                 <select name=\"accnt\">\r\n");

                           

                                    

                                    for(Account ac:acc) {

                                          out.println("<option value="+ac.getAccountNumber()+">");

                                         out.println( ac.getAccountNumber());

                                         out.println("-");

                                         out.println(ac.getAccountType());

                                          out.println("</option>");

                                          }

                                        

                             

                                   out.println("</td></tr><tr><td><input type=\"radio\" name=\"money\" value=\"Deposit\" >Deposit <input type=\"radio\" name=\"money\" value=\"Withdraw\">withdraw </td></tr>"+

                                   

                                   "<tr><td>Amount:</td><td><input type=\"text\" name=\"amount\" size=\"20\"> </td></tr> "+

                                    "<tr><td>Description</td><td><input type=\"text\" name=\"description\"  size=\"20\"></td></tr> "+

                                   "<tr><td><input type=\"submit\" name=\"doTransaction\" size=\"20\"></tr></td></table> </form>\r\n" +

                                                 "</body>\r\n" +

                                                 "</html>");

         
                                   
                           

	}
      
}