package org.capg.service;

import java.util.List;

import org.capg.dao.ILoginDao;
import org.capg.dao.LoginDaoImpl;
import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public class LoginServiceImpl implements ILoginService{

	private ILoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		/*if(loginBean.getUserName().equals("tom") && 
				loginBean.getUserPassword().equals("tom123")) {
			return true;
		}*/
		
		/*if(loginDao.isValidLogin(loginBean))
			return true;*/
		
		return loginDao.isValidLogin(loginBean);
	}

	@Override
	public boolean createCustomer(Customer customer) {
		
		return loginDao.createCustomer(customer);
	}

	@Override
	public Account createAccount(Account account) {
		
		return loginDao.createAccount(account);
	}

	@Override
	public List<Account> maketransaction(String st) {
		
		return loginDao.maketransaction(st);
	}

	@Override
	public List<Account> getAllAccount(String st) {
		
	
		return loginDao.getAllAccount(st);
	}

	@Override
	public Transaction createTransacation(Transaction transaction) {
		
		return loginDao.createTransacation(transaction);
	}

	@Override
	public Account getAccount(Long AccNo) {
		
		return loginDao.getAccount(AccNo);
	}

	@Override
	public void TocreateAccount(Account toAccount) {
		
	 loginDao.TocreateAccount(toAccount);
		
	}

	@Override
	public List<Transaction> getAllTransactions(int CustId) {
		// TODO Auto-generated method stub
		return loginDao.getAllTransactions(CustId);
	}
	
	public void updateAccount(Account toAccount) {
		
		 loginDao.updateAccount(toAccount);
	}
}
