package org.capg.dao;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public interface ILoginDao {
	public Customer isValidLogin(LoginBean loginBean);
	
	public boolean createCustomer(Customer customer);
	
	
	public Account createAccount(Account account);
	
	public List<Account> maketransaction(String st);
	
	public List<Account> getAllAccount(String st);
	
	//public List<Account> printTransaction(int CustId);
	
	public Transaction createTransacation(Transaction transaction);
	
	public Account getAccount(Long acc);
	public void TocreateAccount(Account toAccount);
	
	 public List<Transaction> getAllTransactions(int CustId);
	 public void updateAccount(Account toAccount);
	
	
}
