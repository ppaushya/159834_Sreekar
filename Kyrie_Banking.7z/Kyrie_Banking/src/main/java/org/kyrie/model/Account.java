package org.kyrie.model;

import java.time.LocalDate;

public class Account {
	
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accType=" + accType + ", date=" + date + ", openingBal=" + openingBal
				+ ", description=" + description + "]";
	}
	
	public Account() {
		
	}
	private long accNo;
	private AccountType accType;
	private LocalDate date;
	private long openingBal;
	private String description;
	public Account(long accNo, AccountType accType, LocalDate date, long openingBal, String description) {
		super();
		this.accNo = accNo;
		this.accType = accType;
		this.date = date;
		this.openingBal = openingBal;
		this.description = description;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(AccountType accountType) {
		this.accType = accountType;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public long getOpeningBal() {
		return openingBal;
	}
	public void setOpeningBal(long openingBal) {
		this.openingBal = openingBal;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
