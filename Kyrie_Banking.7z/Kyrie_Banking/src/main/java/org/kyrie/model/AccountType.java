package org.kyrie.model;

public enum AccountType {
	SAVINGS,CURRENT,RD,FD;
}
