package org.kyrie.model;

import java.time.LocalDate;

public class Transaction {

	private long transactionId;
	private LocalDate date;
	private int transactionAmt;
	private String transactionType;
	private String fromAccount;
	private String toAccount;
	private String description;
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getTransactionAmt() {
		return transactionAmt;
	}
	public void setTransactionAmt(int transactionAmt) {
		this.transactionAmt = transactionAmt;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(String fromAccount) {
		this.fromAccount = fromAccount;
	}
	public String getToAccount() {
		return toAccount;
	}
	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", date=" + date + ", transactionAmt=" + transactionAmt
				+ ", transactionType=" + transactionType + ", fromAccount=" + fromAccount + ", toAccount=" + toAccount
				+ ", description=" + description + "]";
	}
	public Transaction(long transactionId, LocalDate date, int transactionAmt, String transactionType,
			String fromAccount, String toAccount, String description) {
		super();
		this.transactionId = transactionId;
		this.date = date;
		this.transactionAmt = transactionAmt;
		this.transactionType = transactionType;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.description = description;
	}
	public Transaction() {
	
	
}
}