package org.kyrie.boot;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.kyrie.model.Account;
import org.kyrie.model.Customer;
import org.kyrie.service.CustomerServiceImp;
import org.kyrie.service.ICustomerService;
import org.kyrie.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		ICustomerService customerService= new CustomerServiceImp();
		UserInteraction userinteraction= new UserInteraction();
		//userinteraction.getCustomeDetails();
		Scanner scan= new Scanner(System.in);
		int  choice;
		String option;
		do {
		System.out.println("1.Create Customer");
		System.out.println("2.List Customers");
		System.out.println("3.Create account");
		System.out.println("Enter Your choice:");
		choice=scan.nextInt();
				
			switch(choice) {		
			case 1:
				
				int count=customerService.getAllCustomers().size();
				
				//Customer customer=userinteraction.getCustomeDetails();
				customerService.createCustomer(userinteraction.getCustomeDetails());
				
				
				if(count==customerService.getAllCustomers().size())
					UserInteraction.printError("Customer Creation Error! Please Try Again!");
					
				
				break;
			case 2:
				
				List<Customer> customers= customerService.getAllCustomers();
				UserInteraction.printCustomers(customers);
				break;
		   	case 3:
		   		System.out.println("Enter Id");
		   		 int custId=scan.nextInt();
		   		 System.out.println(userinteraction.findCustomer(custId));
		   		 
		   		Set <Account> acct =userinteraction.getAccountDetails(custId);
				break;
			default:
				System.out.println("Sorry! Invalid Choice");
				System.exit(0);
			
			}
			System.out.println("Do you wish to contine?[y|n]:");
			option=scan.next();
			
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
		
		
		System.out.println();
		

	}

}
