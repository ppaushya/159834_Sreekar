package org.kyrie.view;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.kyrie.dao.CustomerDaoImp;
import org.kyrie.model.Account;
import org.kyrie.model.AccountType;
import org.kyrie.model.Address;
import org.kyrie.model.Customer;
import org.kyrie.service.CustomerServiceImp;
import org.kyrie.util.Utilty;

public class UserInteraction {
	static UserInteraction userinteraction= new UserInteraction();
	static CustomerServiceImp customerservice= new CustomerServiceImp();
	Scanner scan = new Scanner(System.in);
	static Customer customer = new Customer();
	public Customer getCustomeDetails() {
		
		
		
		customer.setCustomerId(Utilty.generateCustomerId());
		customer.setFirstName(validfirstName());
		customer.setLastName(validlastName());
		customer.setEmailId(validateEmail());
		customer.setMobileNo(validMobileNo());
		customer.setDate(validdateofbirth());
		customer.setAddress(getAddress());
		//customer.setDate(validdateofbirth());
		return customer;		
	}
  
	public Set<Account> getAccountDetails(int customerId) {
		 Account account = new Account();
		 String put;
		 Set<Account> account1 = new HashSet<>();
		 do {
		account.setAccNo(Utilty.generateCustomerId());
		
		System.out.println("Choose Account Type[1.Saving,2.Current,3.FD,4.RD]:");
		int choice = scan.nextInt();
		account.setAccType(assignAccountType(choice));
		account.setDate(LocalDate.now());
		System.out.println("Enter the opening balance");
		long bal= scan.nextLong();
		account.setOpeningBal(bal);
		System.out.println("Enter the description about the account");
		String str = scan.next();
		account.setDescription(str);
		account1.add(account);
		System.out.println("Do you want to make one more account [y/n]");
   	    //Scanner scan = new Scanner(System.in);
   	    put= scan.next();
		 } while(put.charAt(0)=='y'||put.charAt(0)=='Y');
		
		return account1;
		

		
		
	}
	
	public String validfirstName() {
		
		
		 System.out.println("Enter the User First Name");
		 String str= scan.next();
		 if(!str.matches("[A-Z]{1}[a-z,A-Z]{2}")) {
			 System.out.println("Enter the Frist Name Again!");	 
		 }else
	return str;
		return str;
		 
	}
	
	public String validlastName() {
		
		
		 System.out.println("Enter the User Last Name");
		 String str= scan.next();
		 if(!str.matches("[A-Z]{1}[a-z,A-Z]{2,}")) {
			 System.out.println("Enter the Last Name Again!");	 
		 }else
	return str;
		return str;
		 
	}
	
	public String validMobileNo() {
		
		
		 System.out.println("Enter the Mobile no");
		 String a= scan.next();
		 if(!a.matches("[0-9]{10}")) {
			 System.out.println("Enter the Mobile Again!");	 
		 }else
     	return a;
		return a;
	}	
		 public LocalDate validdateofbirth() {
				
				
			 System.out.println("Enter the DOB");
			 String a= scan.next();
			 int dd=Integer.parseInt(a.substring(0, 2));
			 int mm=Integer.parseInt(a.substring(3,5));
			 int yyyy=Integer.parseInt(a.substring(6, 10));
			 
			 LocalDate dob= LocalDate.of(yyyy, mm, dd);
			 
			 
			 if(!a.matches("\\d{2}[-]\\d{2}[-]\\d{4}")) {
				 System.out.println("Enter the DOB Again!");	 
			 }else
		return dob;
			return dob;
		 }
		 
		 public String validateEmail() {
			 System.out.println("Enter the email");
			 String a= scan.next();
			 if(!a.matches("[A-Z,a-z,0-9]{5}[@]{1}[A-Z,a-z,0-9]{5}[.]{1}[a-z,A-Z]{3}")) {
				 System.out.println("Enter the DOB Again!");	 
			 }else
		return a;
			return a;
			 
		 }
				
	public Address getAddress() {
		
		Address address= new Address();
		System.out.println("Enter the addressLine 1");
		address.setAddressLine1(scan.next());
		System.out.println("Enter the addressLine 2");
		address.setAddressLine2(scan.next());
		System.out.println("Enter the City");
		address.setCity(scan.next());
		System.out.println("Enter the state");
		address.setState(scan.next());
		System.out.println("Enter the Pincode (###-###))");
		address.setPincode(scan.next());
		return address;
		
		
		
	}


	public static void printError(String string) {
		
		// TODO Auto-generated method stub
		
	}
//	public static Customer findCustomer(int customerId) {
//		for(Customer customer: customerservice.getAllCustomers()) {
//			if(customer.getCustomerId()==customerId) {
////				System.out.println(" Hence verified! Do u like create account for the above customer?");
//				 //userinteraction.getAccountDetails(customerId);
//	   		
//		}
//		System.out.println("Invalid UserID");
//		System.exit(0);;
//		return customer;
//		}
	
 	public  Customer findCustomer( int custId) {
		int b =custId;
		List<Customer> customer= customerservice.getAllCustomers();
		//List<Customer> customer=CustomerDaoImp.dummyDb();
		Iterator<Customer> lst=customer.iterator();
		while(lst.hasNext()) {
			Customer a=lst.next();	
		if(b==a.getCustomerId()) {
			System.out.println("valid ");
			return a;
		}
		}return null;
		}			
//		return customer;
//		return customer;
//	}
//		return (List<Customer>) lst;
//		}
		
		
	public static AccountType assignAccountType(int value) {
		switch(value) {
		case 1:
			return AccountType.SAVINGS;
		case 2:
			return AccountType.CURRENT;
		case 3:
			return AccountType.RD;
		case 4:
			return AccountType.FD;
		default:
			System.out.println("Invalid Account Type");
			System.exit(0);
		}
		
		return null;
	}
	
	
	


	public static void printCustomers(List<Customer> customers) {
		// TODO Auto-generated method stub
		System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
					+"\t"+ customer.getEmailId() + "\t" + customer.getMobileNo() );
		
	}
}
}