package org.kyrie.util;
import org.kyrie.model.Customer;

public class Utilty {

	public static int generateCustomerId() {
		return (int) (Math.random()*1000)/10;
	}
	
	
}


