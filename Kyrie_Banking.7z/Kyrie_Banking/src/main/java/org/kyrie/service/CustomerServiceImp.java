package org.kyrie.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.kyrie.dao.CustomerDaoImp;
import org.kyrie.dao.CustomerDbImp;
import org.kyrie.dao.ICustomerDao;
import org.kyrie.model.Account;
import org.kyrie.model.Customer;


public class CustomerServiceImp implements ICustomerService{
    

	private ICustomerDao customerDb = new CustomerDaoImp();
	
	public boolean createCustomer(Customer customer) {
		if(isValidCustomer(customer)) {
			customerDb.create_Customer(customer);

			return true;
		}else {
			return false;
		}
	}

	private boolean isValidCustomer(Customer customer) {
		boolean success = false;
		if(customer.getDateOfBirth().isBefore(LocalDate.now())) {
			if(customer.getMobileNo().matches("[7-9]{1}\\d{9}")) {
				success = true;
			}else {
				success = false;
			}
		}
		return success;
	}

	public List<Customer> getAllCustomers() {
		return customerDb.getAllCustomers();
	}

	public Customer getCustomerFromCustomerId(long customerId) {
		return customerDb.get_Customer_From_CustomerId(customerId);
	}
}
