package org.kyrie.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.kyrie.dao.CustomerDaoImp;
import org.kyrie.dao.ICustomerDao;
import org.kyrie.model.Account;
import org.kyrie.model.Customer;

public class CustomerServiceImp implements ICustomerService{
    
	
	private ICustomerDao customerDao=new CustomerDaoImp();
	@Override
	public void createCustomer(Customer customer) {
		
		customerDao.createCustomer(customer);
		
	}
	
	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		if(customer.getDate().isBefore(LocalDate.now())) {
			if(customer.getMobileNo().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		
		
		return flag;

	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		              return customerDao.getAllCustomer();
	}

	@Override
	public void assignCustomer(Set<Account> acc, int CustId) {
		acc=b; 
		CustId=a;
		
		for(int i=0;i>getAllCustomers().size();i++){
			getAllCustomers().get(i).get
		}
		// TODO Auto-generated method stub
		
	}
	

}