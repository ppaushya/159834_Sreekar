package org.kyrie.service;

import java.util.Set;

import org.kyrie.model.Account;



public interface IAccountService {
	
public boolean createAccount(Account account) ;
	
	public Set<Account> getAllAccounts();
	
	public Account getAccountFromAccountId(long accountId);

	public double getCurrentBalanceOfAccount(Account account);

}
