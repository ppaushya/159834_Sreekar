package org.kyrie.service;

import java.util.Set;

import org.kyrie.dao.AccountDbImp;
import org.kyrie.dao.IAccountDao;
import org.kyrie.dao.ITransactionDao;
import org.kyrie.dao.TransactionDbImp;
import org.kyrie.model.Account;
import org.kyrie.model.Customer;
import org.kyrie.model.Transaction;



public class AccountServiceImp  implements IAccountService{

	
	
	Customer customer;
	IAccountDao accountDao;
	
	public AccountServiceImp(Customer customer) {
		super();
		this.customer = customer;
//		accountDao = new AccountDaoImpl(customer);
		accountDao = new AccountDbImp(customer);
	}

	public boolean createAccount(Account account) {
		accountDao.create_Account(account);
		return true;
	}

	public Set<Account> getAllAccounts() {
		return accountDao.getAllAccounts();
	}

	public Account getAccountFromAccountId(long accountId) {
		return accountDao.get_Account_From_AccountId(accountId);
	}

	public double getCurrentBalanceOfAccount(Account account) {
//		ITransactionDao transactionDao = new TransactionDaoImpl();
		ITransactionDao transactionDao = new TransactionDbImp();
		Set<Transaction> transactions = transactionDao.getAllTransactionsOfAccount(account);
		double balance = account.getOpeningBalance();
		for(Transaction transaction:transactions) {
			if(transaction.getTransactionType().equals("Credit")) {
//				System.out.println("t "+balance+"-> + "+transaction.getAmount());
				balance += transaction.getAmount();
			}else if(transaction.getTransactionType().equals("Debit")){
//				System.out.println("t "+balance+"-> - "+transaction.getAmount());
				balance -= transaction.getAmount();
			}else if(transaction.getTransactionType().equals("Fund Transfer")){
				if(transaction.getFromAccount().getAccountNumber() == account.getAccountNumber()) {
//					System.out.println("t "+balance+"-> - "+transaction.getAmount());
					balance -= transaction.getAmount();
				}
				if(transaction.getToAccount().getAccountNumber() == account.getAccountNumber()){
//					System.out.println("t "+balance+"-> + "+transaction.getAmount());
					balance += transaction.getAmount();
				}
			}
		}
		return balance;
	}

}


