package org.kyrie.dao;

import java.util.List;

import org.kyrie.model.Account;
import org.kyrie.model.Customer;

public interface ICustomerDao {
	
	public  List<Customer> getAllCustomer();
	public void createCustomer (Customer customer);
   public void createAccount (Account account);
	

}
