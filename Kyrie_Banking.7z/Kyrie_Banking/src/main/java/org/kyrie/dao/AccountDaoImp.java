package org.kyrie.dao;

import java.util.HashSet;
import java.util.Set;

import org.kyrie.model.Account;
import org.kyrie.model.Customer;
import org.kyrie.util.IdGenerator;



public class AccountDaoImp implements IAccountDao{
private Customer customer;
	
	public AccountDaoImp(Customer customer) {
		super();
		this.customer = customer;
	}

	public Set<Account> getAllAccounts() {
		return customer.getAccounts();
	}

	public Account get_Account_From_AccountId(long accountId) {
		Set<Account> accounts = customer.getAccounts();
		for(Account account:accounts) {
			if(account!=null) {
				if(account.getAccountNumber()==accountId) {
					return account;
				}
			}
		}
		return null;
	}

	public void create_Account(Account account) {
		account.setAccountNumber(IdGenerator.generateAccountNumber());
		customer.getAccounts().add(account);
	}

	@Override
	public Set<Long> get_All_AccountIds() {
		Set<Long> accountIds = new HashSet<>();
		for(Account account:customer.getAccounts()) {
			accountIds.add(account.getAccountNumber());
		}
		return accountIds;
	}

}



