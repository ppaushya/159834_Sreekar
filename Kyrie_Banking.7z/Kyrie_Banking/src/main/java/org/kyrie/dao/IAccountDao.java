package org.kyrie.dao;

import java.util.Set;

import org.kyrie.model.Account;



public interface IAccountDao {
public Set<Account> getAllAccounts();
	
	public Set<Long> get_All_AccountIds();
	
	public Account get_Account_From_AccountId(long accountId);
	
	public void create_Account(Account account);

}
