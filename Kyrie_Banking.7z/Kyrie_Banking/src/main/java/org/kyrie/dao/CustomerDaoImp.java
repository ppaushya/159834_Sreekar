package org.kyrie.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.kyrie.model.Account;
import org.kyrie.model.Address;
import org.kyrie.model.Customer;

public  class CustomerDaoImp implements ICustomerDao {


	private  List<Customer> customers=dummyDb();
	
	public static  List<Customer> dummyDb(){
		List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("23,west Car St", "2nd St", "Chennai", "TN", "234442");
		customers.add(new Customer(123,"Jack","Thomson","jack@gmail.com", "8890912345",LocalDate.of(1991, 01, 23),
				address));
		
		Address address1=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", "657657");
		customers.add(new Customer(1090,"Tom","Jerry","tom@gmail.com","9090912345" ,LocalDate.of(1987, 12, 23),
				address1));
		
		return customers;
	}

	//public List<Customer> getAllCustomers() {
		
		//return customers;
	//}

	@Override
	public void createCustomer(Customer customer) {
		
		customers.add(customer);
	}




	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return customers;
	}

	@Override
	public void createAccount(Account account) {
		customers.add(account);
		
	}

	



//	@Override
//	public List<Customer> getAllCustomer() {
//		// TODO Auto-generated method stub
//		return null;
//	}

}