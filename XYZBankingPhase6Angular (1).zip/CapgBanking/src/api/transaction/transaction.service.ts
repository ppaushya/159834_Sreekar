import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch'
import 'rxjs/add/operator/do';
import { Transaction } from "../../app/transaction/transaction";
import { Message } from "../../app/message/message";

@Injectable()
export class TransactionService{

    //private _transactionsUrl = "./api/transaction/transactions.json";
    private _transactionsUrl = "http://localhost:8083/api/v1/transaction";

    constructor(private _http: HttpClient){

    }

    getTransactionsOfCustomer(customerId: number): Observable<Transaction[]>{
        return this._http.get<Transaction[]>(this._transactionsUrl+"/customer/"+customerId)
        //.do(data => console.log(data))
        //.do(data => console.log("all: "+JSON.stringify(data)))
        .catch(this.handleError);
    }

    getTransactionsOfAccount(accountId: number): Observable<Transaction[]>{
        return this._http.get<Transaction[]>(this._transactionsUrl+"/account/"+accountId)
        //.do(data => console.log(data))
        //.do(data => console.log("all: "+JSON.stringify(data)))
        .catch(this.handleError);
    }

    getTransactionsByDate(customerId: number,fromDate: string,toDate: string): Observable<Transaction[]>{
        console.log(this._transactionsUrl+"/customer/"+customerId+"/date/"+fromDate+"/"+toDate);
        return this._http.get<Transaction[]>(
            this._transactionsUrl+"/customer/"+customerId+"/date/"+fromDate+"/"+toDate)
        //.do(data => console.log(data))
        //.do(data => console.log("all: "+JSON.stringify(data)))
        .catch(this.handleError);
    }

    doTransaction(transaction: Transaction): Observable<Message>{
        return this._http.post<Message>(this._transactionsUrl,transaction,{})
        //.do(data => console.log(data))
        //.do(data => console.log("all: "+JSON.stringify(data)))
        .catch(this.handleError);
    }

    private handleError(err: HttpErrorResponse){
        console.error(err.message);
        return Observable.throw(err.message);
    }
}