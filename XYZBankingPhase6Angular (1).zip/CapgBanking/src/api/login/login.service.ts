import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { ILogin } from "../../app/login/login";
import { Observable } from "rxjs/Observable";
import { ICustomer } from "../../app/register/customer";

@Injectable()
export class LoginService{

    private _loginUrl = "http://localhost:8083/api/v1/login";

    private customer:ICustomer;
    public setCustomer(customer:ICustomer): void{
        this.customer = customer;
    }
    public getCustomer(): ICustomer{
        return this.customer;
    }

    constructor(private http: HttpClient){

    }

    doLogin(customer:ICustomer): Observable<ICustomer>{
        return this.http.post<ICustomer>(this._loginUrl,customer,{});
    }
}