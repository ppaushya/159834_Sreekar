import {Component, OnInit} from '@angular/core';
import { Account } from '../account/account';
import { AccountService } from '../../api/account/account.service';
import { LoginService } from '../../api/login/login.service';
import { TransactionService } from '../../api/transaction/transaction.service';
import { Transaction } from '../transaction/transaction';

@Component({
    selector:'pm-fund-transfer',
    templateUrl: './fund-transfer.component.html',
    providers: [AccountService,TransactionService],
    styleUrls: ['./fund-transfer.component.css']
})

export class FundTransferComponent implements OnInit{
    pageTitle: string='Fund Transfer';
    errorMessage: string;
    transaction: Transaction = new Transaction();
    

    accounts:Account[] = [];
    allAccounts:Account[] = [];
    filteredAccounts:Account[] = [];
    
    message: string;
    showMessage: boolean = false;

    constructor(private _accountService: AccountService,private _transactionService: TransactionService,private loginService:LoginService){
        this.transaction.transactionType = 'fund transfer';
    }

    ngOnInit(): void {
        console.log("In OnInit");
        this._accountService.getAccounts(this.loginService.getCustomer().customerId)
            .subscribe(
                accounts => {
                    this.accounts = accounts;
                },
                error => this.errorMessage = <any>error
            );
        this._accountService.getAllAccounts()
            .subscribe(
                allAccounts => {
                    this.allAccounts = allAccounts;
                    this.filteredAccounts = allAccounts;
                },
                error => this.errorMessage = <any>error
            );
    }

    doFundTransfer(){
        console.log(this.transaction);
        this._transactionService.doTransaction(this.transaction)
        .subscribe(
            message => {
                console.log(message);
                if(message['success']==true){
                    this.showMessage = true;
                    this.message="Transaction successful";
                }
            },
            error => this.errorMessage = <any>error
        );
    }

    change():void{
        console.log("change");
        this.filteredAccounts = this.allAccounts.filter(
            (account:Account) => {
                return account.accountNumber != this.transaction.fromAccount.accountNumber;
            }
        );
    }
}