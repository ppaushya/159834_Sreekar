import {Component, OnInit} from '@angular/core';
import { Account } from '../account/account';
import { AccountService } from '../../api/account/account.service';
import { LoginService } from '../../api/login/login.service';

@Component({
    selector:'pm-create-account',
    templateUrl: './create-account.component.html',
    providers:[AccountService],
    styleUrls: ['./create-account.component.css']
})

export class CreateAccountComponent implements OnInit{
    pageTitle: string='Create Account';
    message: string;
    showMessage: boolean = false;

    account:Account = new Account();
    allAccounts:Account[];

    constructor(private accountService:AccountService,private loginService:LoginService){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        this.getAccounts();
    }

    getAccounts():void{
        this.accountService.getAccounts(this.loginService.getCustomer().customerId)
        .subscribe(allAccounts =>{
            this.allAccounts = allAccounts;
        });
    }

    createAccount():void{
        this.accountService.createAccount(this.account,this.loginService.getCustomer().customerId)
        .subscribe(message =>{
            console.log(message);
            if(message['success']==true){
                this.showMessage = true;
                this.message="Account created successfully";
                this.getAccounts();
            }
        });
    }
}