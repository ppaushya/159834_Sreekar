export class Account{
    accountNumber:number;
    accountType:string;
    openingDate:string;
    openingBalance:number;
    description:string;
}