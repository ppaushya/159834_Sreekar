import { Account } from "../account/account";

export class Transaction{
    transactionId:number;
    transactionDate:string;
    fromAccount:Account = new Account();
    toAccount:Account = new Account();
    amount:number;
    transactionType:string;
    description:string;
}