export class Message{
    message: string;
    success: boolean;
}