import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../api/login/login.service';
import { ILogin } from './login';
import { ICustomer } from '../register/customer';

@Component({
    selector:'pm-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit{
    pageTitle: string='Login';
    customer: ICustomer = new ICustomer();

    constructor(private router: Router,private loginService:LoginService){
        
    }

    ngOnInit(): void {
        console.log("login In OnInit");
        
    }

    doLogin():void{
        console.log("login");
        console.log(this.customer);
        this.loginService.doLogin(this.customer)
            .subscribe(customer =>{
                console.log(customer);
                if(customer.emailId==this.customer.emailId){
                    console.log("login successful");
                    this.loginService.setCustomer(customer);
                    this.router.navigate(['/mainpage']);
                }
            });
    }

    goToSignup():void{
        this.router.navigate(['/register']);
    }
}