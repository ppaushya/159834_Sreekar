import {Component, OnInit} from '@angular/core';
import { TransactionService } from '../../api/transaction/transaction.service';
import { Transaction } from '../transaction/transaction';
import { LoginService } from '../../api/login/login.service';

@Component({
    selector:'pm-transaction-summary',
    templateUrl: './transaction-summary.component.html',
    providers: [TransactionService],
    styleUrls: ['./transaction-summary.component.css']
})

export class TransactionSummaryComponent implements OnInit{
    pageTitle: string='Transaction Summary';
    errorMessage: string;
    fromDate: string;
    toDate: string;

    transactions:Transaction[] = [];

    constructor(private _transactionService: TransactionService,private loginService:LoginService){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        this.refreshTransactions();
    }

    refreshTransactions():void{
        this._transactionService.getTransactionsOfCustomer(this.loginService.getCustomer().customerId)
        .subscribe(
            transactions => {
                this.transactions = transactions;
            },
            error => this.errorMessage = <any>error
        );
    }

    getTransactionsByDate():void{
        this._transactionService.getTransactionsByDate(
            this.loginService.getCustomer().customerId,this.fromDate,this.toDate)
        .subscribe(
            transactions => {
                console.log(transactions);
                this.transactions = transactions;
            },
            error => this.errorMessage = <any>error
        );
    }
}