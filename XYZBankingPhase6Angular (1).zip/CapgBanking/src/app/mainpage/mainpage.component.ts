import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../api/login/login.service';
import { ICustomer } from '../register/customer';

@Component({
    selector:'pm-mainpage',
    templateUrl: './mainpage.component.html',
    styleUrls: ['./mainpage.component.css']
})

export class MainPageComponent implements OnInit{
    pageTitle: string='Mainpage';
    customer: ICustomer;

    constructor(private router: Router,private loginService:LoginService){
        this.customer = loginService.getCustomer();
    }

    ngOnInit(): void {
        console.log("In OnInit");
        
        this.router.navigate(['/mainpage/createaccount']);
    }
}