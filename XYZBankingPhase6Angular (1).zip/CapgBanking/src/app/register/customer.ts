import { Address } from "./address";

export class ICustomer{
    customerId:number;
    firstName:string;
    lastName:string;
    dateOfBirth:string;
    emailId:string;
    mobileNo:string;
    password:string;
    address: Address = new Address();
}