import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { ICustomer } from './customer';
import { RegisterService } from '../../api/register/register.service';
import { Address } from './address';

@Component({
    selector:'pm-dv',
    templateUrl: './register.component.html',
    providers: [RegisterService],
    styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit{
    pageTitle: string='Register';
    customer: ICustomer = new ICustomer();

    constructor(private router: Router,private registerService:RegisterService){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        
    }

    register(){
        this.registerService.register(this.customer)
        .subscribe(message =>{
            console.log(message);
            if(message['success']==true){
                this.router.navigate(['/login']);
            }
        });
    }

    goToLogin(){
        this.router.navigate(['/login']);
    }
}