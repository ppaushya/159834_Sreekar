package day17;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Bootclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	EntityManagerFactory emp=Persistence.createEntityManagerFactory("jpademo");
	EntityManager entitymanager=emp.createEntityManager();
	 EntityTransaction transaction=entitymanager.getTransaction();
	 
	 transaction.begin();
	 
	 
	 Employee emp1 = new Employee(100,"RAM","Krishna",2000.00);
	 entitymanager.persist(emp1);
	 
	 
	 Employee emp2 = new Employee();
	emp2.setFirstName("Jon");
	 emp2.setLastName("Casher");
	 emp2.setSalary(5000.00);
	 emp2.setPswrd("Jon222");
	 emp2.setDate(new Date());
	 
	 
	 Customer customer = new Customer("Krish","Pavan",(LocalDate.now()),"krish@gmail.com","9848585858","krish@123");
	 Address address= new Address("1006","HRT Nagar" ,"hyd","TG","550414");
	 Account account = new Account(AccountType.valueOf("SAVINGS"), (LocalDate.now()), 500000, "Saving");
	 Transaction transaction1 = new Transaction((LocalDate.now()),5000.00,"Deposit","5000 has been deposited");
	 
	 
	 transaction.commit();
	

	}

}
