package day17;

public enum AccountType {
	
	SAVINGS,CURRENT,RD,FD;
//
//	public static AccountType valueOf(int int1) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
