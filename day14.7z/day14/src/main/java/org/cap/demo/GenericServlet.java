package org.cap.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class GenericServlet extends javax.servlet.GenericServlet {
	private static final long serialVersionUID = 1L;
       
	 public void init(ServletConfig Config) throws ServletException{
		   System.out.println("Generic Start");
	 }
	 public void destroy(){
		   System.out.println(" Generic end");
	}
    public GenericServlet() {
        super();
    }

	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		PrintWriter out =response.getWriter();
		out.println("Generic" );
		System.out.println("1");
	}

}
