package org.cap.prac.Day12;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class Product implements Serializable{
	private int productId;
	private double price;
	private LocalDate expDate;
	private String productName;
	
	public Product() {
		
	}
	
	public Product(int productId, double price, LocalDate expDate, String productName) {
		super();
		this.productId = productId;
		this.price = price;
		this.expDate = expDate;
		this.productName = productName;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", price=" + price + ", expDate=" + expDate + ", productName="
				+ productName + "]";
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getExpDate() {
		return expDate;
	}
	public void setExpDate(LocalDate expDate) {
		this.expDate = expDate;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	

	
	public static void main(String[] args) throws FileNotFoundException  {
		
		
		public static void writeOnFile(List<Product> products) {
			File file = new File("D:\\FileDemoJava\\products.txt");
			
			try(FileOutputStream fileOutputStream = new FileOutputStream(file);
					ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)){
				
//				Product product = new Product(101, "Mobile", 10, 15000, LocalDate.of(2050, 12, 12));
					for(Product product:products) {
						objectOutputStream.writeObject(product);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		
		public static void readFromFile() {
			File file = new File("D:\\FileDemoJava\\products.txt");
			
			FileInputStream inputStream=null;
			ObjectInputStream objectInputStream = null;
			try	{
				inputStream = new FileInputStream(file);
				objectInputStream = new ObjectInputStream(inputStream);
					
					Product product;
					/*while((product = (Product) objectInputStream.readObject()) != null) {
						System.out.println(product);
					}*/
					do {
						product = (Product) objectInputStream.readObject();
						System.out.println(product);
					}while(objectInputStream != null);

				} catch (IOException | ClassNotFoundException e) {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
					e.printStackTrace();
				}
		}
	}
