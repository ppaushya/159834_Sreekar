package org.cap.file;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadWriteEmployee {
	
	static Scanner scanner = new Scanner(System.in);
	static int empId = 100;
	static List<Employee> employees = new ArrayList<>();
	static List<Integer> employeesEnds = new ArrayList<>();

	public static void main(String[] args) {
		int len = 2;
		for(int i=0;i<len;i++) {
			Employee employee = promptEmployee();
			employees.add(employee);
		}
		writeOnFile(employees);
		readFromFile(len);
	}

	public static Employee promptEmployee() {
		Employee employee = new Employee();
		employee.setEmpId(++empId);
		
		System.out.println("Enter first name:");
		employee.setFirstName(scanner.next());
		
		System.out.println("Enter salary:");
		employee.setSalary(scanner.nextDouble());
		
		System.out.println("Enter gender:");
		employee.setGender(scanner.next().charAt(0));
		
		System.out.println("Is employee permanent?:");
		char s = scanner.next().charAt(0);
		employee.setPermanent(s=='y'||s=='Y');
		
		return employee;
	}
	
	private static void writeOnFile(List<Employee> employees) {
		File file = new File("D:\\FileDemoJava\\employees.txt");
		
		try(FileOutputStream fileOutputStream = new FileOutputStream(file);
			DataOutputStream dataOutputStream = new DataOutputStream(fileOutputStream)){
			
			for(Employee employee:employees) {
				dataOutputStream.writeInt(employee.getEmpId());
				dataOutputStream.writeDouble(employee.getSalary());
				dataOutputStream.writeChar(employee.getGender());
				dataOutputStream.writeBoolean(employee.isPermanent());
				employeesEnds.add(dataOutputStream.size());
//				dataOutputStream.write(employee.getFirstName().getBytes());
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void readFromFile(int len) {
		File file = new File("D:\\FileDemoJava\\employees.txt");
		
		try(FileInputStream fileInputStream = new FileInputStream(file);
			DataInputStream dataInputStream = new DataInputStream(fileInputStream)){
			
			for(int i=0;i<len;i++) {
				int id = dataInputStream.readInt();
				double salary = dataInputStream.readDouble();
				char gender = dataInputStream.readChar();
				boolean per = dataInputStream.readBoolean();
//				String name = dataInputStream.read
				
				System.out.println(id);
				System.out.println(salary);
				System.out.println(gender);
				System.out.println(per);
				System.out.println(employeesEnds.get(i));
//				System.out.println(name);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
