package org.xyz.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.xyz.model.CustomerBean;
import org.xyz.model.LoginBean;

@Repository("loginDao")
@Transactional
public interface ILoginDao extends JpaRepository<CustomerBean,Long>{

	//public CustomerBean isValidLogin(CustomerBean customerBean);
	public CustomerBean getCustomerByEmailIdAndPassword(String email,String password);
}
