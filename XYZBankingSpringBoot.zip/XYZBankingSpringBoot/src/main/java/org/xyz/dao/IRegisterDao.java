package org.xyz.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.xyz.model.CustomerBean;

@Repository("registerDao")
@Transactional
public interface IRegisterDao extends JpaRepository<CustomerBean,Long>{

	//public boolean registerCustomer(CustomerBean customerBean);
}
