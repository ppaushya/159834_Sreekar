package org.cap.game.reg.service;

import java.util.Scanner;

import org.cap.game.reg.view.Userinteraction;

public class RegistrationServiceImp implements RegistrationService {
   Userinteraction userinteraction = new Userinteraction();
   Scanner scan = new Scanner(System.in);
	@Override
	public String validCustomerName() {
		boolean flag=true;
		 System.out.println("Enter the User First Name");
		 
		 String str= scan.next();
		 while(flag) {
		 
		 if(!str.matches("[a-z,A-Z]{8}")) {
			
			 System.out.println("Enter the Frist Name Again!");	 
			 str=scan.next();
		 }
		 flag=false;
		 }
	return str;
	
	}

	@Override
	public String validMobileno() {

		 System.out.println("Enter the Mobile no");
		 String a= scan.next();
		 if(!a.matches("[0-9]{10}")) {
			 System.out.println("Enter the Mobile Again!");	 
		 }else
    	return a;
		return a;
		
	}

}
