package org.cap.game.reg.view;

import java.util.Scanner;

import org.cap.game.reg.game.Registration;
import org.cap.game.reg.service.RegistrationService;
import org.cap.game.reg.service.RegistrationServiceImp;

public class Userinteraction {
	Scanner scan= new Scanner(System.in);
	Registration reg = new Registration();
	RegistrationService service = new RegistrationServiceImp();
	
public Registration createCustomer() {
	
	reg.setCustomerName(service.validCustomerName());
	
	System.out.println("Enter the Mobile number");
    reg.setMobileNo(scan.nextInt());	
    System.out.println("Enter registration fee");
    reg.setRegisFee(scan.nextInt());
    System.out.println("Enter the age");
    reg.setAge(scan.nextInt());
	return reg;
    

}

}
