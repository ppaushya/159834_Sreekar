package org.cap.game.reg.service;

public interface RegistrationService {
	 public String validCustomerName();
	 public String validMobileno();
	

}
