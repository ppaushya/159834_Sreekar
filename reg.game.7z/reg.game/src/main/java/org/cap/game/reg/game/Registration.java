package org.cap.game.reg.game;

public class Registration {
	private int registrationId;
	 private String CustomerName;
	 private String mobileNo;
	 private double regisFee;
	 private int age;
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getRegisFee() {
		return regisFee;
	}
	public void setRegisFee(double regisFee) {
		this.regisFee = regisFee;
	}
	public Registration(int registrationId, String customerName, String mobileNo, double regisFee, int age) {
		super();
		this.registrationId = registrationId;
		CustomerName = customerName;
		this.mobileNo = mobileNo;
		this.regisFee = regisFee;
		this.age = age;
	}
	public Registration() {
		
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Regitration [registrationId=" + registrationId + ", CustomerName=" + CustomerName + ", mobileNo="
				+ mobileNo + ", regisFee=" + regisFee + ", age=" + age + "]";
	}
	 

}
