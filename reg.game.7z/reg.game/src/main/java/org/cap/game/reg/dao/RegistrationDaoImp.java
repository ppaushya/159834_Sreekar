package org.cap.game.reg.dao;

import org.cap.game.reg.game.Registration;

public class RegistrationDaoImp implements RegistartionDao {

	
	@Override
	public Registration addCustomer(Registration registartion) {
		// TODO Auto-generated method stub
		return null;
	}

}
