package org.cap.game.reg.dao;

import org.cap.game.reg.game.Registration;

public interface RegistartionDao {
	
	public Registration addCustomer(Registration registartion);
	

}
